import React, { useId } from 'react';

/* ============================================================================
   Anvaya — the mark
   ---------------------------------------------------------------------------
   Anvaya (अन्वय) means "connection, the thread that links things in order".
   The mark is that idea in one glyph: an "A" drawn as a single continuous
   thread, with a saffron bead where the two arms meet — the record, and the
   links between records.

   Rules:
     • never stretch, rotate or recolour the mark
     • minimum size 20px on screen, 8mm in print
     • on dark, use the tile form; on light, the tile also works
     • the bead is always saffron — it is the only fixed colour in the identity
   ========================================================================== */

export function LogoMark({ size = 32, tone = 'tile', title = 'Anvaya' }) {
  const id = useId().replace(/[:]/g, '');
  const grad = `anvaya-grad-${id}`;
  const shade = `anvaya-shade-${id}`;

  return (
    <svg
      className="brandmark"
      width={size}
      height={size}
      viewBox="0 0 64 64"
      role="img"
      aria-label={title}
      xmlns="http://www.w3.org/2000/svg"
    >
      {tone === 'tile' && (
        <>
          <defs>
            <linearGradient id={grad} x1="8" y1="0" x2="56" y2="64" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#5B52EE" />
              <stop offset="0.55" stopColor="#4F46E5" />
              <stop offset="1" stopColor="#2F279F" />
            </linearGradient>
            <linearGradient id={shade} x1="32" y1="0" x2="32" y2="64" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#fff" stopOpacity="0.22" />
              <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
            </linearGradient>
          </defs>
          <rect x="0" y="0" width="64" height="64" rx="17" fill={`url(#${grad})`} />
          <rect x="0" y="0" width="64" height="64" rx="17" fill={`url(#${shade})`} />
        </>
      )}

      {/* the thread: one continuous stroke, left foot → apex → right foot */}
      <path
        d="M19.5 47 L32 17.5 L44.5 47"
        fill="none"
        stroke="#fff"
        strokeWidth="5.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* the crossbar, slightly lighter so the apex bead stays the focus */}
      <path
        d="M25.4 36.4 H38.6"
        fill="none"
        stroke="#fff"
        strokeWidth="4.6"
        strokeLinecap="round"
        opacity="0.92"
      />
      {/* the bead: the connection itself */}
      <circle cx="32" cy="17.5" r="5" fill="#F2A63B" stroke="#fff" strokeWidth="1.6" />
    </svg>
  );
}

export function LogoWord({ className = '' }) {
  return <span className={`lockup-word ${className}`.trim()}>anvaya<span className="dot">.</span></span>;
}

/** Mark + wordmark + the small platform line. Use this in the sidebar and on
 *  the login card. `onLight` flips the wordmark to ink for light surfaces. */
export function LogoLockup({ size = 34, sub = 'CRM PLATFORM', onLight = false, tone = 'tile' }) {
  return (
    <div className={`lockup${onLight ? ' on-light' : ''}`}>
      <LogoMark size={size} tone={tone} />
      <div className="lockup-text">
        <LogoWord />
        {sub && <span className="lockup-sub">{sub}</span>}
      </div>
    </div>
  );
}

export default LogoMark;
