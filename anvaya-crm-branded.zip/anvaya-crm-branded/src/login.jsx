import React, { useState } from 'react';
import {
  Mail, Lock, Eye, EyeOff, ArrowRight, AlertCircle, CheckCircle2,
  CloudOff, ShieldCheck, Database, Link2, User, Building2
} from 'lucide-react';
import { LogoLockup } from './brand.jsx';

/* ============================================================================
   Anvaya — sign-in
   ---------------------------------------------------------------------------
   The app works without a server (IndexedDB, offline-first), so this page has
   two honest doors:

     • sign in / create an account — needs a Supabase project connected
     • continue in a local workspace — no account, nothing leaves the device

   The connection fields live here because a first-time user has no other way to
   reach them: without a URL and key there is nothing to sign in to.
   ========================================================================== */

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function friendly(message = '') {
  const m = message.toLowerCase();
  if (m.includes('invalid login credentials')) return 'That email and password do not match an account.';
  if (m.includes('email not confirmed')) return 'Check your inbox — this account still needs its email confirmed.';
  if (m.includes('user already registered')) return 'An account with that email already exists. Sign in instead.';
  if (m.includes('password should be at least')) return 'Use at least 8 characters for the password.';
  if (m.includes('rate limit') || m.includes('too many')) return 'Too many attempts. Wait a minute and try again.';
  if (m.includes('failed to fetch') || m.includes('networkerror')) return 'Could not reach Supabase. Check the project URL and your connection.';
  if (m.includes('invalid api key') || m.includes('no api key')) return 'That key was rejected. Copy the anon / publishable key again.';
  return message || 'Something went wrong. Try again.';
}

export default function Login({ supabase, url, key, onConnect, onLocal, persist, onPersist }) {
  const configured = Boolean(url && key);

  const [mode, setMode] = useState('signin');          // signin | signup | reset
  const [name, setName] = useState('');
  const [workspace, setWorkspace] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [peek, setPeek] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState(null);          // {kind, text}
  const [connOpen, setConnOpen] = useState(!configured);
  const [draftUrl, setDraftUrl] = useState(url || '');
  const [draftKey, setDraftKey] = useState(key || '');

  const reset = (next) => { setMode(next); setError(''); setNotice(null); };

  async function submit(e) {
    e.preventDefault();
    setError('');
    setNotice(null);

    if (!configured) { setError('Connect your Supabase project below, or continue in a local workspace.'); return; }
    if (!EMAIL.test(email.trim())) { setError('Enter a valid email address.'); return; }

    if (mode === 'reset') {
      setBusy(true);
      try {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: window.location.origin
        });
        if (err) throw err;
        setNotice({ kind: 'okay', text: `If ${email.trim()} has an account, a reset link is on its way.` });
      } catch (err) { setError(friendly(err.message)); }
      setBusy(false);
      return;
    }

    if (password.length < 8) { setError('Use at least 8 characters for the password.'); return; }
    if (mode === 'signup' && password !== confirm) { setError('The two passwords do not match.'); return; }
    if (mode === 'signup' && name.trim().length < 2) { setError('Tell us your name so your team knows who you are.'); return; }

    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: name.trim(), workspace: workspace.trim() || null } }
        });
        if (err) throw err;
        if (!data.session) {
          setNotice({ kind: 'okay', text: 'Account created. Confirm your email address, then sign in.' });
          setMode('signin');
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
      }
    } catch (err) {
      setError(friendly(err.message));
    }
    setBusy(false);
  }

  function saveConnection(e) {
    e.preventDefault();
    const u = draftUrl.trim().replace(/\/+$/, '');
    const k = draftKey.trim();
    if (!/^https?:\/\//.test(u)) { setError('The project URL should look like https://your-project.supabase.co'); return; }
    if (k.length < 20) { setError('That does not look like a Supabase anon key.'); return; }
    setError('');
    onConnect({ url: u, key: k });
    setConnOpen(false);
    setNotice({ kind: 'okay', text: 'Project connected. Sign in with the account you created in Supabase.' });
  }

  const heading = mode === 'signup' ? 'Create your workspace'
    : mode === 'reset' ? 'Reset your password'
      : 'Welcome back';

  const lede = mode === 'signup'
    ? 'One place for every lead, deal and customer conversation.'
    : mode === 'reset'
      ? 'We will email you a link to set a new password.'
      : 'Sign in to pick up where your team left off.';

  return (
    <div className="authpage">
      {/* ---------------------------------------------------------- brand */}
      <aside className="authbrand">
        <LogoLockup size={40} sub="CRM PLATFORM" />

        <div>
          <h1>Every relationship,<br />in one <em>thread</em>.</h1>
          <p>
            Anvaya connects the lead, the deal and the customer into a single
            history — so nothing your team learned gets lost between screens.
          </p>
          <ul className="authpoints">
            <li><i><Database size={14} /></i><span><b>Works offline.</b> Records live in your browser and sync when you reconnect.</span></li>
            <li><i><ShieldCheck size={14} /></i><span><b>Yours alone.</b> Supabase row-level security keeps each workspace separate.</span></li>
            <li><i><CloudOff size={14} /></i><span><b>No lock-in.</b> Your own Supabase project, your own data, export any time.</span></li>
          </ul>
        </div>

        <div className="authfoot">
          <span>© {new Date().getFullYear()} Anvaya CRM</span>
          <span>Made for Indian sales teams</span>
        </div>
      </aside>

      {/* ----------------------------------------------------------- form */}
      <main className="authpanel">
        <div className="authcard">
          <LogoLockup size={34} sub="CRM PLATFORM" onLight />

          <h2>{heading}</h2>
          <p className="lede">{lede}</p>

          {!configured && (
            <div className="note info">
              <AlertCircle size={15} />
              <span>No Supabase project is connected yet. You can connect one below, or work locally on this device.</span>
            </div>
          )}

          {error && <div className="note bad" role="alert"><AlertCircle size={15} /><span>{error}</span></div>}
          {notice && <div className={`note ${notice.kind}`}><CheckCircle2 size={15} /><span>{notice.text}</span></div>}

          <form onSubmit={submit} noValidate>
            {mode === 'signup' && (
              <>
                <div className="field">
                  <label htmlFor="name">Your name</label>
                  <div className="control">
                    <User size={15} />
                    <input id="name" value={name} onChange={e => setName(e.target.value)}
                      placeholder="Snehasis Saha" autoComplete="name" />
                  </div>
                </div>
                <div className="field">
                  <label htmlFor="workspace">Workspace name <span style={{ fontWeight: 400, color: 'var(--ink-300)' }}>— optional</span></label>
                  <div className="control">
                    <Building2 size={15} />
                    <input id="workspace" value={workspace} onChange={e => setWorkspace(e.target.value)}
                      placeholder="Brightline Systems" autoComplete="organization" />
                  </div>
                </div>
              </>
            )}

            <div className="field">
              <label htmlFor="email">Work email</label>
              <div className="control">
                <Mail size={15} />
                <input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="you@company.in" autoComplete="email" inputMode="email" />
              </div>
            </div>

            {mode !== 'reset' && (
              <div className="field">
                <label htmlFor="password">Password</label>
                <div className="control">
                  <Lock size={15} />
                  <input id="password" type={peek ? 'text' : 'password'} value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={mode === 'signup' ? 'At least 8 characters' : 'Your password'}
                    autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} />
                  <button type="button" className="peek" onClick={() => setPeek(p => !p)}
                    aria-label={peek ? 'Hide password' : 'Show password'}>
                    {peek ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>
            )}

            {mode === 'signup' && (
              <div className="field">
                <label htmlFor="confirm">Confirm password</label>
                <div className="control">
                  <Lock size={15} />
                  <input id="confirm" type={peek ? 'text' : 'password'} value={confirm}
                    onChange={e => setConfirm(e.target.value)} placeholder="Repeat it"
                    autoComplete="new-password" />
                </div>
              </div>
            )}

            {mode === 'signin' && (
              <div className="authrow">
                <label className="check">
                  <input type="checkbox" checked={persist} onChange={e => onPersist(e.target.checked)} />
                  Keep me signed in
                </label>
                <button type="button" className="linkbtn" onClick={() => reset('reset')}>Forgot password?</button>
              </div>
            )}

            <button className="authsubmit" type="submit" disabled={busy}>
              {busy ? <span className="spin" /> : null}
              {busy ? 'Working…' : mode === 'signup' ? 'Create account'
                : mode === 'reset' ? 'Send reset link' : 'Sign in'}
              {!busy && <ArrowRight size={16} />}
            </button>
          </form>

          <p className="switchline">
            {mode === 'signin' && <>New here? <button className="linkbtn" onClick={() => reset('signup')}>Create an account</button></>}
            {mode === 'signup' && <>Already have one? <button className="linkbtn" onClick={() => reset('signin')}>Sign in</button></>}
            {mode === 'reset' && <button className="linkbtn" onClick={() => reset('signin')}>Back to sign in</button>}
          </p>

          <div className="authdivider">or</div>

          <button className="ghostbtn" type="button" onClick={onLocal}>
            <CloudOff size={15} />
            Continue in a local workspace
          </button>
          <p className="hint" style={{ textAlign: 'center', marginTop: 8 }}>
            No account, nothing leaves this browser. You can connect a project later.
          </p>

          <details className="connbox" open={connOpen} onToggle={e => setConnOpen(e.currentTarget.open)}>
            <summary><Link2 size={13} /> {configured ? 'Supabase connection' : 'Connect your Supabase project'}</summary>
            <form onSubmit={saveConnection}>
              <div className="field">
                <label htmlFor="surl">Project URL</label>
                <div className="control">
                  <input id="surl" className="noicon" value={draftUrl} onChange={e => setDraftUrl(e.target.value)}
                    placeholder="https://abcdefgh.supabase.co" autoComplete="off" spellCheck="false" />
                </div>
              </div>
              <div className="field">
                <label htmlFor="skey">Anon / publishable key</label>
                <div className="control">
                  <input id="skey" className="noicon" value={draftKey} onChange={e => setDraftKey(e.target.value)}
                    placeholder="eyJhbGciOi…" autoComplete="off" spellCheck="false" />
                </div>
              </div>
              <button className="ghostbtn" type="submit">Save connection</button>
              <p className="hint" style={{ marginTop: 8 }}>
                Supabase → Project Settings → API. Use the anon key only; never a service-role key in a browser.
              </p>
            </form>
          </details>

          <p className="authlegal">
            By continuing you agree to keep customer data lawful and consensual.
            Anvaya stores records in this browser and, when connected, in your own Supabase project.
          </p>
        </div>
      </main>
    </div>
  );
}
