create table if not exists public.crm_records (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null check (type in ('contact','company','lead','deal','task','activity')),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
alter table public.crm_records enable row level security;
create policy "Users manage their own CRM records"
on public.crm_records for all to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
create index if not exists crm_records_user_updated_idx
on public.crm_records(user_id, updated_at desc);