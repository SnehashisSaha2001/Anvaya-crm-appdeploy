# Anvaya CRM — brand guide

The identity is built on the meaning of the word. **Anvaya** (अन्वय) is Sanskrit
for *connection — the thread that links things in order*. A CRM is exactly that:
the thread between a lead, a deal and the customer it becomes.

## The mark

An **A** drawn as one continuous thread, with a saffron bead where the two arms
meet. The thread is the record; the bead is the connection between records.

| | |
|---|---|
| Files | `public/logo-mark.svg`, `public/logo-lockup.svg`, `public/favicon.svg` |
| In code | `src/brand.jsx` → `<LogoMark />`, `<LogoWord />`, `<LogoLockup />` |
| Clear space | at least half the tile width on every side |
| Minimum size | 20 px on screen, 8 mm in print |
| On dark | use the tile form — the gradient holds up on the sidebar |
| Never | stretch, rotate, add shadows, or recolour the bead |

The bead is `--saffron-500` (#F2A63B) in every context. It is the one fixed
colour in the system; the indigo may shift, the bead may not.

## Palette

| Token | Hex | Use |
|---|---|---|
| `--brand-500` | `#4F46E5` | Primary actions, active nav, the thread |
| `--brand-700` | `#2F279F` | Pressed states, gradient end |
| `--brand-50` | `#F4F3FF` | Tints, hover rows, notes |
| `--saffron-500` | `#F2A63B` | Accents only — the bead, the active bar, counts. Never body text |
| `--ink-900` | `#0B1020` | Headings, sidebar |
| `--ink-500` | `#5A6280` | Secondary text |
| `--line` | `#E6E8F2` | Borders, dividers |
| `--bg` | `#F5F6FB` | Page background |
| `--ok` | `#0E9F87` | Positive deltas, online state |
| `--danger` | `#C6404A` | Errors, destructive actions |

Change the six `--brand-*` values in `src/style.css` and the entire product
follows — no component hard-codes a brand colour.

## Type

**Manrope** for display, headings and numbers (800/700). **DM Sans** for body and
UI (400–600). Both are loaded from Google Fonts in `src/style.css`.

Numbers are tabular wherever they can change — pipeline values, counts, totals —
so a column of them lines up.

## Voice

Short, concrete, human. Name the thing (lead, deal, invoice), not the abstraction.
Never claim something the product does not do: if there is no server connected,
the screen says so instead of pretending.

## Where the brand appears

- Sidebar lockup (dark tile form)
- Login page: full lockup on the brand panel, the light form on the card
- Favicon and `theme-color` (`#0D1130`)
- Open Graph title and image in `index.html`
