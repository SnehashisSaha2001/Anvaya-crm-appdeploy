import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // relative asset paths, so dist/index.html also opens straight from disk
  base: './',
  plugins: [react()],
  server: { port: 5173, host: true }
});
