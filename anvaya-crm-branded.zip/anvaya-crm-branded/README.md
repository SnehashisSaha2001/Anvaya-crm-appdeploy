# Anvaya CRM — source project

Offline-first CRM starter rebuilt around Supabase + IndexedDB.

## Brand and sign-in

The app now ships with its own identity and a real sign-in gate.

- **Logo** — `src/brand.jsx` (`<LogoMark/>`, `<LogoLockup/>`), assets in `public/`.
  The mark is an "A" drawn as one continuous thread with a saffron bead at the
  joint: *anvaya* means "connection". Rules are in `BRAND.md`.
- **Theme** — one token block at the top of `src/style.css`. Dark indigo sidebar,
  light content, indigo primary, saffron accent. Change the six `--brand-*`
  values and the whole product follows.
- **Login** — `src/login.jsx`, rendered before the app shell until you are signed
  in or choose a local workspace. It handles sign-in, sign-up, password reset,
  the "keep me signed in" persistence choice, and the Supabase connection fields,
  so a first-time user has one place to start. Sign out lives in the sidebar.

Nothing is faked: with no Supabase project connected the form says so, and
"Continue in a local workspace" is the offline-first path, not a pretend login.

See `anvaya-brand-preview.html` (shipped alongside) for the mark, palette, type
and the login screen in one page.

## Features
- Overview dashboard, contacts, companies, leads, deals, tasks, calendar and reports
- Create, edit and soft-delete CRM records
- IndexedDB local persistence and queued changes while offline
- Supabase email/password authentication and cloud sync
- CSV import/export
- Responsive desktop and mobile layout

## Requirements
- Node.js 20+
- A Supabase project (optional; the app works locally without one)

> `package.json` pinned `@vitejs/plugin-react@^6` against `vite@^6`; those two
> cannot resolve together, so `npm install` failed out of the box. It is pinned
> to `^4.3.4` now, and `vite.config.js` was added (it was missing).

## Run locally
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

## Connect Supabase
1. Run `supabase/schema.sql` in the Supabase SQL Editor.
2. Open the app. On the sign-in screen, expand **Connect your Supabase project**
   and paste the Project URL and the publishable/anon key. (Also available later
   under Settings.)
3. Create an account, or sign in.
4. Press **Sync now** in the sidebar.

Use only the publishable/anon key in the browser. Never expose a service-role key.

## Offline and conflict behavior
The app stores records and pending writes in IndexedDB. Local edits are queued and sent to Supabase after the user is authenticated and online. The current synchronization strategy uses `updated_at` last-write-wins comparison for downloaded records; it is a lightweight baseline, not a collaborative merge engine. Back up/sync before clearing browser storage.

## Notes
- The workspace starts with sample records on first launch.
- This source bundle is a portable Vite/React project implementing the Anvaya CRM feature set and offline-first Supabase pattern.
- The deployed AppDeploy app is available at https://anvaya-crm-vgc73o.v2.appdeploy.ai/
